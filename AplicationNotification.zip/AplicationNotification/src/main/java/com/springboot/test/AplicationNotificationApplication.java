package com.springboot.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicationNotificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicationNotificationApplication.class, args);
	}

}
